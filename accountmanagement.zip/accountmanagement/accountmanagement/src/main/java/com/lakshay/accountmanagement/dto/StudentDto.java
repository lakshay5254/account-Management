package com.lakshay.accountmanagement.dto;

public class StudentDto {
}
