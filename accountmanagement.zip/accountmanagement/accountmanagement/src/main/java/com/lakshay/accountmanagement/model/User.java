package com.lakshay.accountmanagement.model;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Builder
public class User {
    @Id
    @GeneratedValue
    private  long userid;
    private String username;
    private int mobile;
    private String email;
    private String password;

    @ManyToOne
    @JoinColumn
    private Role role;

}