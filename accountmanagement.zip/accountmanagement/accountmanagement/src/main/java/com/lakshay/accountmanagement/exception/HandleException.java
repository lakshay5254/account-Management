package com.lakshay.accountmanagement.exception;

public class HandleException extends RuntimeException {


    public HandleException(String exMessage) {
        super(exMessage);
    }

}
