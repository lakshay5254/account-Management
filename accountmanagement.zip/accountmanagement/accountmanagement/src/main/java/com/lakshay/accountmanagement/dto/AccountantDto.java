package com.lakshay.accountmanagement.dto;


import com.lakshay.accountmanagement.model.User;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AccountantDto {
    private String username;
    private String mobile;
    private String email;
    private String password;



    public AccountantDto(User user) {
        this.username=user.getUsername();
        this.mobile=Integer.toString(user.getMobile());
        this.email=user.getEmail();
        this.password="";
    }
}
