package com.lakshay.accountmanagement.model;

public class Student {
}
