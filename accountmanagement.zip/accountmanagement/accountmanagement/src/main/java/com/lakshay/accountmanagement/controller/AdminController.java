package com.lakshay.accountmanagement.controller;

import com.lakshay.accountmanagement.dto.AccountantDto;
import com.lakshay.accountmanagement.model.User;
import com.lakshay.accountmanagement.service.AdminService;
import lombok.AllArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/admin")
@AllArgsConstructor
public class AdminController {

    private final AdminService adminService;

    @GetMapping("/contact")
    public String contactPage(){
        return "admin/contact";
    }

    @GetMapping("/about")
    public String aboutPage(){
        return "admin/about";
    }


    @GetMapping(value={"/index","/home","/"})
    public String index(){

        return "admin/index";
    }

    @GetMapping("/addAccountant")
    public String addAccountant(){

        return "admin/addAccountant";
    }


    @GetMapping("/viewAccountants")
    public String viewAccountants(){

        return "redirect:/admin/getAllAccountants";
    }
    @GetMapping("/updateAccountant")
    public ModelAndView updateAccountant(@RequestParam long userid){
        ModelAndView mv=new ModelAndView("admin/updateAccountant");
        mv.addObject("accountant",adminService.getAccountant(userid));
        return mv;
    }
    @PostMapping("/editAndUpdateAccountant")
    public ModelAndView editAndUpdateAccountant(User user){
        ModelAndView mv=new ModelAndView("admin/index");
        if(adminService.updateAccountantService(user)){
            mv.addObject("message","Successfully updated");
        }else{
            mv.addObject("message","Error in updating");
        }
        return mv;
    }


    @PostMapping("/addAccountant")
    public ModelAndView addAccountant(AccountantDto accountantDto){
        ModelAndView mv=new ModelAndView("admin/index");
        if(adminService.addAccountantService(accountantDto)){
            mv.addObject("message","Successfully Added");
        }else{
            mv.addObject("message","User Already Present");
        }
        return mv;
    }

    @GetMapping("/getAllAccountants")
    public ModelAndView getAllAccountant(){
        ModelAndView mv=new ModelAndView("admin/viewAccountants");
        mv.addObject("allAccountants",adminService.viewAllAccountantsService());
        return mv;
    }




}
