package com.lakshay.accountmanagement.dto;

import lombok.Builder;
import lombok.Data;

@Data
public class LoginRequest {
    String username;
    String password;
}
