package com.lakshay.accountmanagement.repository;




import com.lakshay.accountmanagement.model.Role;
import com.lakshay.accountmanagement.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Long> {
    Optional<User> findByUsername(String username);
    List<User> findAllByRole(Role role);

    @Modifying
    @Query("update User u set u.username= :username, u.mobile = :mobile, u.email = :email, u.password = :password where u.userid = :userid")
    void setUserInfoById(@Param("username") String username,@Param("mobile") int mobile,@Param("email") String email,@Param("password") String password,@Param("userid") long userId);
}
