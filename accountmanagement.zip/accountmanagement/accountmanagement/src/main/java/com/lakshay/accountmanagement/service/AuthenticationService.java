package com.lakshay.accountmanagement.service;



import com.lakshay.accountmanagement.dto.AuthenticationResponse;
import com.lakshay.accountmanagement.dto.LoginRequest;
import com.lakshay.accountmanagement.dto.SignupDto;
import com.lakshay.accountmanagement.model.Role;
import com.lakshay.accountmanagement.model.User;
import com.lakshay.accountmanagement.repository.RoleRepository;
import com.lakshay.accountmanagement.repository.UserRepository;
import lombok.AllArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.servlet.http.HttpServletRequest;
import java.security.InvalidParameterException;
import java.util.ArrayList;
import java.util.List;

@Service
@AllArgsConstructor
@Transactional
public class AuthenticationService {
    private final UserRepository userRepository;
    private final AuthenticationManager authenticationManager;
    private final PasswordEncoder passwordEncoder;
    private  final HttpServletRequest httpServletRequest;

    private final RoleRepository roleRepository;

    public Boolean signupService(SignupDto signupDto) {
        if(userRepository.findByUsername(signupDto.getUsername()).isPresent()){

            return false;

        }else {

            User newUser= User.builder()
                    .username(signupDto.getUsername())
                    .email(signupDto.getEmail())
                    .mobile(Integer.parseInt(signupDto.getMobile()))
                    .password(passwordEncoder.encode(signupDto.getPassword()))
                    .role(roleRepository.getById(1))
                    .build();
            userRepository.save(newUser);
            return true;
        }

    }
    @Transactional
    public AuthenticationResponse loginService(LoginRequest loginRequest) {
        Authentication authenticate=authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginRequest.getUsername(),loginRequest.getPassword()));

        SecurityContextHolder.getContext().setAuthentication(authenticate);
        return AuthenticationResponse.builder().username(loginRequest.getUsername()).build();
    }


    @Transactional(readOnly = true)
    public User getCurrentUser(){
        String name= SecurityContextHolder.getContext().getAuthentication().getName();
        return userRepository.findByUsername(name).orElseThrow(()->new UsernameNotFoundException("username not found"));
    }


}
