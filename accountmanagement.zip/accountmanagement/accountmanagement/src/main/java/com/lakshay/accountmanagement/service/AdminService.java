package com.lakshay.accountmanagement.service;


import com.lakshay.accountmanagement.dto.AccountantDto;
import com.lakshay.accountmanagement.exception.HandleException;
import com.lakshay.accountmanagement.model.User;
import com.lakshay.accountmanagement.repository.RoleRepository;
import com.lakshay.accountmanagement.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdminService {
    private final UserRepository userRepository;
    private  final RoleRepository roleRepository;

    public Boolean addAccountantService(AccountantDto accountantDto) {
        if(userRepository.findByUsername(accountantDto.getUsername()).isPresent()){
            return false;
        }else {
            User user=new User();
            user.setUsername(accountantDto.getUsername());
            user.setEmail(accountantDto.getEmail());
            user.setMobile(Integer.parseInt(accountantDto.getMobile()));
            user.setPassword(accountantDto.getPassword());
            user.setRole(roleRepository.getById(2));

            userRepository.save(user);
            return true;
        }


    }

    public List<User> viewAllAccountantsService() {
        List<User> allAccountants=userRepository.findAllByRole(roleRepository.getById(2));
//        List<AccountantDto> result=allAccountants.stream().map(AccountantDto::new).collect(Collectors.toList());
        return allAccountants;
    }

    public User getAccountant(long userid) {
        User user=userRepository.findById(userid).orElseThrow(()->new HandleException("Username not found"));
        return user;
    }

    public boolean updateAccountantService(User user) {
            userRepository.setUserInfoById(user.getUsername(),user.getMobile(),user.getEmail(),user.getPassword(),user.getUserid());
                return true;
    }
}
