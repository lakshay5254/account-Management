package com.lakshay.accountmanagement.model;

public class Accountant {
}
