package com.lakshay.accountmanagement.controller;

import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/")
public class HomeController {
  /*  @GetMapping("/")
    public String index(){
        if (SecurityContextHolder.getContext().getAuthentication() != null &&
                SecurityContextHolder.getContext().getAuthentication().isAuthenticated()){
            return "/admin/index";
        }
        return "index";
    }*/

    @GetMapping("/contact")
    public String contactPage(){
        return "contact";
    }


    @GetMapping("/about")
    public String aboutPage(){
        return "about";
    }

    @GetMapping("/home")
    public String indexPage(){

        return "index";
    }


    @GetMapping("/signin")
    public String signinPage(){
        return "signin";
    }


    @GetMapping("/signup")
    public String signupPage(){
        return "signup";
    }
}
