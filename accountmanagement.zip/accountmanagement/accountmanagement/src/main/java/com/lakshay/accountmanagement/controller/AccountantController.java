package com.lakshay.accountmanagement.controller;

import com.lakshay.accountmanagement.dto.AccountantDto;
import com.lakshay.accountmanagement.dto.StudentDto;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


@Controller
@RequestMapping("/accountant")
public class AccountantController {


    @GetMapping("/index")
    public String index(){
        return "accountant/index";
    }


    @PostMapping("/addStudent")
    public String addStudent(StudentDto studentDto){
        return "admin/index";
    }

    @GetMapping("/viewAllStudents")
    public String viewAllStudents(){
        return "admin/index";
    }


    @GetMapping("/viewStudent/{id}")
    public String viewStudent(@RequestParam String id){
        return "admin/index";
    }

    @GetMapping("/viewFeeDueStudents")
    public String viewFeeDueStudents(@RequestParam String id){
        return "admin/index";
    }

    @GetMapping("/editStudent/{id}")
    public String editStudent(@RequestParam String id){
        return "admin/index";
    }

}
