package com.lakshay.accountmanagement.controller;



import com.lakshay.accountmanagement.dto.AuthenticationResponse;
import com.lakshay.accountmanagement.dto.LoginRequest;
import com.lakshay.accountmanagement.dto.SignupDto;
import com.lakshay.accountmanagement.service.AuthenticationService;
import lombok.AllArgsConstructor;
import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;


@Controller
@AllArgsConstructor
public class AuthenticationController {
    private final AuthenticationService authenticationService;

    @PostMapping("/signup")
    public ModelAndView signup(@ModelAttribute SignupDto signupDto){
        ModelAndView mv=new ModelAndView("admin/index");
        if(authenticationService.signupService(signupDto)){
            mv.addObject("message","Successfully Added");
        }else{
            mv.addObject("message","Admin Already Present");
        }
        return mv;

    }

    @PostMapping("/signin")
    public ModelAndView login( LoginRequest loginRequest) {
        authenticationService.loginService(loginRequest);
        return new ModelAndView("admin/index");
    }
}
